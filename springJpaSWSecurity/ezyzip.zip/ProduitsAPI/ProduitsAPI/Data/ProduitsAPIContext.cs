﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ProduitsAPI;

namespace ProduitsAPI.Data
{
    public class ProduitsAPIContext : DbContext
    {
        public ProduitsAPIContext (DbContextOptions<ProduitsAPIContext> options)
            : base(options)
        {
        }

        public DbSet<ProduitsAPI.Product> Product { get; set; } = default!;
    }
}
